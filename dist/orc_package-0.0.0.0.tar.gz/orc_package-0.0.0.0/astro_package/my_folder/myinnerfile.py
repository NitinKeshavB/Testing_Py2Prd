

# import sys

# print(sys.path)

# sys.path.insert(0,"/home/nitinkeshav/astro/")

from astro_package.myouterfile import constant as c
print(c) 

import numpy as np

print(np.__version__)